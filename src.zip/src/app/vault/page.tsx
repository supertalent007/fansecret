import HomeScreen from "@/components/home/home-screen/HomeScreen";

export default async function Home() {
  return <main>{<HomeScreen />}</main>;
}
