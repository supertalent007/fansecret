

export default async function Search() {
  return <main>search</main>;
}
const frequencies: PricingTierFrequency[] = [
	{ id: "1", value: "1", label: "Monthly", priceSuffix: "/month" },
	{ id: "2", value: "2", label: "Annually", priceSuffix: "/year" },
];
