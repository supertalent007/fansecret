const Footer = () => {
	return (
		<footer className='md:px-8 md:py-0 border-t'>
			<div className='container flex  items-center gap-4 h-24'>
				<p className='text-balance text-center text-sm leading-loose text-muted-foreground md:text-left'>
				© Copyright FansSecret
				
				
					
				</p>
			</div>
		</footer>
	);
};
export default Footer;
