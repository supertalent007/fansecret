import HeroSection from "./HeroSection";


const AuthScreen = () => {
	return (
		<div className='flex flex-col'>
			<HeroSection />			
		</div>
	);
};
export default AuthScreen;
